-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema projet_chess
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema projet_chess
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `projet_chess` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `projet_chess` ;

-- -----------------------------------------------------
-- Table `projet_chess`.`groupeprivileges`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`groupeprivileges` (
  `id` INT NOT NULL COMMENT 'Le id du groupe.',
  `nom` VARCHAR(45) NULL DEFAULT NULL COMMENT 'Le nom du groupe qui va s\'afficher sur le site.',
  `id_usagercreation` INT NULL DEFAULT NULL COMMENT 'L\'id de l\'usager qui a créé ce groupe.',
  `datecreation` DATETIME NULL DEFAULT NULL COMMENT 'La date de la création du groupe.',
  PRIMARY KEY (`id`),
  INDEX `usagercreation_idx` (`id_usagercreation` ASC) VISIBLE,
  CONSTRAINT `groupeprivileges_usagercreation`
    FOREIGN KEY (`id_usagercreation`)
    REFERENCES `projet_chess`.`usager` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table décrivant les différentes groupes de privilèges intégrées dans le système d\'administration d\'accès du site.';


-- -----------------------------------------------------
-- Table `projet_chess`.`usager`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`usager` (
  `id` INT NOT NULL COMMENT 'L\'id du compte usager.',
  `compte` VARCHAR(45) NULL DEFAULT NULL COMMENT 'Le nom d\'utilisateur.',
  `motdepasse` VARCHAR(45) NULL DEFAULT NULL COMMENT 'Le mot de passe haché.',
  `id_groupeprivileges` INT NULL DEFAULT NULL COMMENT 'Le groupe de privilèges dont apartient l\'utilisateur.',
  `datecreation` DATETIME NULL DEFAULT NULL COMMENT 'La date de création de l\'utilisateur.',
  PRIMARY KEY (`id`),
  INDEX `usager_groupeprivileges_idx` (`id_groupeprivileges` ASC) VISIBLE,
  CONSTRAINT `usager_groupeprivileges`
    FOREIGN KEY (`id_groupeprivileges`)
    REFERENCES `projet_chess`.`groupeprivileges` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table décrivant les comptes des usagers.';


-- -----------------------------------------------------
-- Table `projet_chess`.`video`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`video` (
  `id` INT NOT NULL COMMENT 'L\'id de la vidéo.',
  `uri` VARCHAR(128) NULL DEFAULT NULL COMMENT 'L\'uri local pour trouver le fichier vidéo dans la persistence hdd.',
  `titre` VARCHAR(45) NOT NULL COMMENT 'Le titre de la vidéo.',
  `id_usagerajout` INT NOT NULL COMMENT 'L\'id de l\'usager qui a fait l\'ajout de la vidéo.',
  `dateajout` DATETIME NOT NULL COMMENT 'La date d\'ajout de la vidéo dans les ressources.',
  PRIMARY KEY (`id`),
  INDEX `video_usagerajout_idx` (`id_usagerajout` ASC) VISIBLE,
  CONSTRAINT `video_usagerajout`
    FOREIGN KEY (`id_usagerajout`)
    REFERENCES `projet_chess`.`usager` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table décrivant les donnés des vidéos stoqués par le controlleur de ressources.';


-- -----------------------------------------------------
-- Table `projet_chess`.`cours`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`cours` (
  `id` INT NOT NULL COMMENT 'L\'id du cours.',
  `cout` INT NOT NULL COMMENT 'Le coût du cours en points monnaie fictive.',
  `dateajout` DATETIME NOT NULL COMMENT 'La date d\'ajout sur le site.',
  `pagecontenu` LONGTEXT NULL DEFAULT NULL COMMENT 'La page en format markup du contenu du cours.',
  `id_video` INT NULL DEFAULT NULL COMMENT 'L\'id du vidéo du cours.',
  `niveau` INT NULL DEFAULT NULL COMMENT 'Le niveau de difficulté du cours de 1 à 3.',
  PRIMARY KEY (`id`),
  INDEX `videocours_idx` (`id_video` ASC) VISIBLE,
  CONSTRAINT `cours_video`
    FOREIGN KEY (`id_video`)
    REFERENCES `projet_chess`.`video` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table décrivant les cours qui sont disponnibles à être consultés.';


-- -----------------------------------------------------
-- Table `projet_chess`.`privilege`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`privilege` (
  `id` INT NOT NULL COMMENT 'L\'id du privilège.',
  `nom` VARCHAR(45) NULL DEFAULT NULL COMMENT 'Le nom unique du privilège.',
  PRIMARY KEY (`id`),
  UNIQUE INDEX `nom_UNIQUE` (`nom` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table qui décrit les privilèges disponnibles à être utilisées par le système afin de déterminer les accès des utilisateurs.';


-- -----------------------------------------------------
-- Table `projet_chess`.`groupeprivileges_privilege`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`groupeprivileges_privilege` (
  `id_groupeprivileges` INT NOT NULL COMMENT 'L\'id du groupe(many).',
  `id_privilege` INT NOT NULL COMMENT 'L\'id du privilège(many).',
  `id_usagerajout` INT NOT NULL COMMENT 'L\'id de l\'usager qui a décidé cet ajout de privilège.',
  `dateajout` DATETIME NOT NULL COMMENT 'La date qui marque le moment de l\'ajout du privilège.',
  PRIMARY KEY (`id_groupeprivileges`, `id_privilege`),
  INDEX `liaison_privilege_idx` (`id_privilege` ASC) VISIBLE,
  INDEX `usagerajout_idx` (`id_usagerajout` ASC) VISIBLE,
  CONSTRAINT `groupeprivileges_privilege_groupeprivileges`
    FOREIGN KEY (`id_groupeprivileges`)
    REFERENCES `projet_chess`.`groupeprivileges` (`id`),
  CONSTRAINT `groupeprivileges_privilege_privilege`
    FOREIGN KEY (`id_privilege`)
    REFERENCES `projet_chess`.`privilege` (`id`),
  CONSTRAINT `groupeprivileges_privilege_usagerajout`
    FOREIGN KEY (`id_usagerajout`)
    REFERENCES `projet_chess`.`usager` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table de liaison many-to-many pour marquer quels privilèges appartiennent à quel groupe.';


-- -----------------------------------------------------
-- Table `projet_chess`.`modedepaiement`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`modedepaiement` (
  `id` INT NOT NULL COMMENT 'L\'id du mode de paiement.',
  `id_usagerparent` INT NOT NULL COMMENT 'L\'id de l\'usager à qui apartient ce mode de paiement.',
  `dateajout` DATETIME NOT NULL COMMENT 'La date de l\'ajout du mode de paiement.',
  `type` INT NOT NULL COMMENT 'Le type du mode de paiement: débit(1), crédit(2) et paypal(3).',
  `carte` VARCHAR(45) NOT NULL COMMENT 'L\'information de la carte(débit ou crédit) ou du courriel paypal.',
  `cvv` VARCHAR(3) NULL DEFAULT NULL COMMENT 'Dans le cas d\'une carte, le code de sécurité de 3 chifres.',
  `dateexpiration` DATETIME NULL DEFAULT NULL COMMENT 'Dans le cas d\'une carte, la date d\'expiration écrite sur la carte.',
  PRIMARY KEY (`id`),
  INDEX `usagerpaiement_idx` (`id_usagerparent` ASC) VISIBLE,
  CONSTRAINT `modedepaiement_usagerparent`
    FOREIGN KEY (`id_usagerparent`)
    REFERENCES `projet_chess`.`usager` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table qui décrit les modes de paiement ajoutés par l\'usager dans son compte.';


-- -----------------------------------------------------
-- Table `projet_chess`.`objetcosmetique`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`objetcosmetique` (
  `id` INT NOT NULL COMMENT 'L\'id de l\'objet comsétique du jeu.',
  `cible` VARCHAR(45) NULL DEFAULT NULL COMMENT 'Colonne qui contient des valeurs décrivant quel élement visuel d\'une partie d\'échecs est visée par l\'objet cosmétique. Exemple: \"chevalier\".',
  `contenu` VARCHAR(45) NULL DEFAULT NULL COMMENT 'Le contenu en format string qui contiendra des descripteurs(ex: \"11513412\") pour accèder aux ressources(ex: image png) des changements cosmétiques dans le terminal(endpoint, en anglais) du controlleur de ressources. Son usage permettera au frontend de chercher l\'image ciblée par le changement pour la partie de jeu qu\'on peut voir sur l\'écran.',
  `dateajout` DATETIME NOT NULL COMMENT 'Date d\'ajout de l\'objet cosmétique dans le domaine global du site.',
  `id_usagerajout` INT NOT NULL COMMENT 'L\'usager responsable pour l\'ajout de l\'objet cosmétique dans le domaine global du site.',
  `achetable` TINYINT NULL DEFAULT NULL COMMENT 'Booléen décrivant si l\'objet cosmétique est achetable.',
  `prix` FLOAT NULL DEFAULT NULL COMMENT 'Le prix à payer en dollars canadiens pour une transaction d\'achat de l\'objet cosmétique.',
  PRIMARY KEY (`id`),
  INDEX `usagerajout_idx` (`id_usagerajout` ASC) VISIBLE,
  CONSTRAINT `objetcosmetique_usagerajout`
    FOREIGN KEY (`id_usagerajout`)
    REFERENCES `projet_chess`.`usager` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table qui décrit les objets qui peuvent modifier le jeu, telle une cosmétique de pièce de jeu d\'échecs. Après un ajout dans la base de données, on peut le rendre disponnible aux usagers pour achat et pour utilisation. Une cosmétique: une image de remplacement d\'une pièce de jeu ou de la table d\'échecs que les gens peuvent acheter.';


-- -----------------------------------------------------
-- Table `projet_chess`.`profiljeu`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`profiljeu` (
  `id` INT NOT NULL COMMENT 'L\'id du profil de jeu.',
  `id_usager` INT NULL DEFAULT NULL COMMENT 'L\'id de l\'usager à qui apartient ce profil.',
  `points` INT NULL DEFAULT NULL COMMENT 'Les points de monnaie fictive.',
  `elo` INT NULL DEFAULT NULL COMMENT 'La cote elo de l\'usager qui sera utilisée pour rendre possible la mise en rangs de celui-ci.',
  `datedernierjeu` DATETIME NULL DEFAULT NULL COMMENT 'La date du dernier jeu joué par l\'utilisateur.',
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_usager_UNIQUE` (`id_usager` ASC) VISIBLE,
  CONSTRAINT `profiljeu`
    FOREIGN KEY (`id_usager`)
    REFERENCES `projet_chess`.`usager` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table décrivant les profils de jeu des utilisateurs en liaison one-to-one avec la table d\'usagers.';


-- -----------------------------------------------------
-- Table `projet_chess`.`partie`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`partie` (
  `id` INT NOT NULL COMMENT 'L\'id de la partie.',
  `id_joueur1` INT NOT NULL COMMENT 'L\'id du joueur blanc.',
  `id_joueur2` INT NOT NULL COMMENT 'L\'id du joueur noir.',
  `historiquetables` JSON NULL DEFAULT NULL COMMENT 'En format json, nous persistons l\'historique des tables jouées par la partie dans le cas d\'un jeu en cours et même fini.',
  `statut` INT NOT NULL COMMENT 'Statut de la partie: pas débutée(0), en cours(1), finie(2).',
  `id_gagnant` INT NULL DEFAULT NULL COMMENT 'L\'id de l\'usager qui a gagné la partie.',
  `datedebut` DATETIME NULL DEFAULT NULL COMMENT 'La date de début de la partie.',
  `datefin` DATETIME NULL DEFAULT NULL COMMENT 'La date de la fin de la partie.',
  PRIMARY KEY (`id`),
  INDEX `partie_joueur1_idx` (`id_joueur1` ASC) VISIBLE,
  INDEX `partie_joueur2_idx` (`id_joueur2` ASC) VISIBLE,
  INDEX `partie_gagnant_idx` (`id_gagnant` ASC) VISIBLE,
  CONSTRAINT `partie_gagnant`
    FOREIGN KEY (`id_gagnant`)
    REFERENCES `projet_chess`.`profiljeu` (`id`),
  CONSTRAINT `partie_joueur1`
    FOREIGN KEY (`id_joueur1`)
    REFERENCES `projet_chess`.`profiljeu` (`id`),
  CONSTRAINT `partie_joueur2`
    FOREIGN KEY (`id_joueur2`)
    REFERENCES `projet_chess`.`profiljeu` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table décrivant les parties en cours de jeu et jouées dans le passé.';


-- -----------------------------------------------------
-- Table `projet_chess`.`transaction`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`transaction` (
  `id` INT NOT NULL COMMENT 'L\'id de la transaction.',
  `id_usager` INT NOT NULL COMMENT 'L\'id de l\'usager qui a effectué la transaction.',
  `montant` FLOAT NOT NULL COMMENT 'Le montant payé de la transaction en dollars canadiens.',
  `dateinitialisation` DATETIME NULL DEFAULT NULL COMMENT 'La date de l\'initialisation de la transaction.',
  `dateconfirmation` DATETIME NULL DEFAULT NULL COMMENT 'La date de confirmation de la transaction.',
  `id_modedepaiement` INT NOT NULL COMMENT 'L\'id du mode de paiement dans le compte de l\'usager pour pouvoir confirmer la transaction.',
  PRIMARY KEY (`id`),
  INDEX `transaction_usager_idx` (`id_usager` ASC) VISIBLE,
  INDEX `transaction_modedepaiement_idx` (`id_modedepaiement` ASC) VISIBLE,
  CONSTRAINT `transaction_modedepaiement`
    FOREIGN KEY (`id_modedepaiement`)
    REFERENCES `projet_chess`.`modedepaiement` (`id`),
  CONSTRAINT `transaction_usager`
    FOREIGN KEY (`id_usager`)
    REFERENCES `projet_chess`.`usager` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table décrivant les différentes transactions effectuées par les usagers.';


-- -----------------------------------------------------
-- Table `projet_chess`.`profiljeu_objetcosmetique`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projet_chess`.`profiljeu_objetcosmetique` (
  `id_profiljeu` INT NOT NULL COMMENT 'L\'id du profil de jeu dont la liaison met en parenté.',
  `id_objetcosmetique` INT NOT NULL COMMENT 'L\'id de l\'objet de cosmétique qui apartient au profil de jeu.',
  `id_transaction` INT NOT NULL COMMENT 'L\'id de la transaction d\'achat de cet objet de jeu lorsque le profil de jeu(l\'usager) est entré en possession.',
  `dateachat` DATETIME NOT NULL COMMENT 'La date de l\'achat de cet objet de jeu lorsque le profil de jeu(l\'usager) est entré en possession.',
  `active` TINYINT NULL DEFAULT NULL COMMENT 'Booléen qui marque si l\'utilisateur a activé cet element visuel pour sont profil de jeu. Ça démarque si on peut le voir lors d\'une partie.',
  PRIMARY KEY (`id_profiljeu`, `id_objetcosmetique`),
  INDEX `profiljeu_objetcosmetique_objetcosmetique_idx` (`id_objetcosmetique` ASC) VISIBLE,
  INDEX `profiljeu_objetcosmetique_transaction_idx` (`id_transaction` ASC) VISIBLE,
  CONSTRAINT `profiljeu_objetcosmetique_objetcosmetique`
    FOREIGN KEY (`id_objetcosmetique`)
    REFERENCES `projet_chess`.`objetcosmetique` (`id`),
  CONSTRAINT `profiljeu_objetcosmetique_profiljeu`
    FOREIGN KEY (`id_profiljeu`)
    REFERENCES `projet_chess`.`profiljeu` (`id`),
  CONSTRAINT `profiljeu_objetcosmetique_transaction`
    FOREIGN KEY (`id_transaction`)
    REFERENCES `projet_chess`.`transaction` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
COMMENT = 'Table contiendrant les liaisons many-to-many entre les profils de jeu et les objets de cosmétique dont ils sont en possession.';


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
